# Eproc+

Extensão do Chrome com melhorias para o eproc do TJSP:

1. **Pesquisa no localizador principal.** Na tela Nova Minuta, o campo "Novo localizador" ganha uma caixa de pesquisa. O campo original continua no formulário e recebe o evento `change` quando você escolhe um item.
2. **Copiar e colar preferências de minuta.** Copia a preferência carregada na tela, com o modelo junto, e recria em outro usuário com 1 clique.

## Instalar

1. Abra `chrome://extensions` e ative o **Modo do desenvolvedor**.
2. Clique em **Carregar sem compactação** e escolha esta pasta, a que contém o `manifest.json`.
3. Atualize as abas do eproc que já estavam abertas.

Para atualizar, troque os arquivos e clique em ⟳ na extensão, em `chrome://extensions`.

> As preferências copiadas ficam guardadas por extensão. Se você usava a extensão antiga "eproc - Preferências de Minuta", use **Exportar** nela antes de removê-la e depois **Importar** na Eproc+.

## Preferências de minuta

Na tela **Nova Minuta**, ao lado de "Atualizar preferência", aparecem dois botões:

- **📋 Copiar (Eproc+)** guarda a preferência carregada na tela. Ficam salvos o modelo, a descrição, o assinante, o tratamento, o status de destino, o sigilo, o agendamento de evento e intimação e o comportamento do localizador. O modelo vai junto: tipo, descrição, classificação, se é público e o texto das seções.
- **📥 Colar (Eproc+)** abre um painel com as preferências guardadas. Marque uma ou várias e clique em **Colar selecionadas**. Cada uma é criada como preferência **individual** do usuário logado. Antes de gravar, a extensão confere se o localizador, o assinante e o tratamento existem na unidade de destino e avisa se algum não existir.

### Copiar várias de uma vez

Na tela do **processo**, no bloco "Ações preferenciais › Minutas", fica o botão **📋 Copiar várias (Eproc+)**. Ele abre uma checklist com as preferências listadas ali (Individuais, Unidade e Ocultas), com filtro por nome e marcação por grupo. A checklist mostra o tempo estimado (cerca de 1,2 s por preferência) e avisa quais já foram copiadas antes, que serão atualizadas.

Para cada preferência marcada, a extensão abre a Nova Minuta já carregada num iframe oculto e faz a mesma cópia do botão individual, com o modelo. Modelos repetidos são lidos uma vez só. A cópia mostra o progresso, pode ser cancelada e não grava nada no eproc.

### Quando o modelo não existe no destino

Se o modelo não existir no destino, a extensão faz o seguinte:
1. Procura um modelo com a mesma descrição e o mesmo tipo e, se achar, usa esse.
2. Se não achar, cria o modelo: tela "Novo modelo padrão", editor e salvamento pelo próprio eproc, tudo numa janela oculta.
3. Grava a preferência já apontando para o modelo encontrado ou criado.

Quando várias preferências usam o mesmo modelo, ele é criado uma vez só. Antes de criar qualquer coisa, a extensão avisa e pede confirmação.

No painel **Colar**:
- há filtro por nome e grupos (Individuais, Unidade, Ocultas e Importadas), cada um com caixa para marcar o grupo inteiro;
- o tempo estimado aparece antes de colar: cerca de 1 s por preferência, mais uns 6 s para cada modelo que precisar ser criado;
- o progresso aparece item a item.

### Kit para colegas

No painel **Colar**, **⬇ Exportar kit** baixa um `.json` com as preferências marcadas e os modelos delas. O colega abre uma Nova Minuta, clica em **Colar (Eproc+)** e depois em **⬆ Importar kit**. As preferências do kit já aparecem marcadas; é só clicar em **Colar selecionadas**.

O ícone da extensão abre o mesmo controle, com mais opções: exportar, importar, renomear e excluir. No popup, a importação abre numa aba própria.

## Como funciona

- `preferencias/pagina.js` roda no mundo da página, porque precisa do jQuery e das funções do eproc.
  - Para copiar, ele chama a `validarPreferencias()` da própria tela, mas troca `gravarPreferencias()` para só guardar a `listaDados`. Assim nada é gravado.
  - Para colar, ele envia a `listaDados` para `gravar_preferencias_cadastrar_formulario`, depois de passar por `validar_acao_preferencial_vinculo_localizadores`. É o mesmo caminho do botão "Salvar Nova Preferência".
- `preferencias/botoes.js` roda isolado. Cuida dos botões, do painel e do `chrome.storage`, e conversa com o `pagina.js` por `window.postMessage`.
- `localizador/pesquisa.js` é a pesquisa do localizador principal.

## Versões e atualização

- A versão aparece no rodapé do popup. **Novidades** mostra o histórico, que fica em `novidades.json`.
- De 6 em 6 horas, o `background.js` lê o `versao.json` do repositório público [HatsuStark/eproc-plus](https://github.com/HatsuStark/eproc-plus). Se houver versão nova, o ícone ganha o selo **novo** e o popup mostra o link para baixar. Também dá para conferir na hora em **Verificar atualização**.
- **Para publicar uma versão:**
  1. Suba o `version` no `manifest.json` e acrescente a versão no topo de `novidades.json`.
  2. Rode `node ferramentas/empacotar-eproc-plus.js <pasta-do-clone-do-repo-publico>`. O script gera `eproc-plus-<versão>.zip`, `versao.json` e `README.md`.
  3. Faça commit e push no repositório público.

## Limitações

- Os IDs de localizador e assinante valem dentro da mesma unidade e da mesma instância do eproc. O eproc cível (`eproc1g`) e o da execução fiscal (`eproc1g-ef`) usam IDs diferentes.
- Para criar o modelo, o usuário de destino precisa de acesso a "Modelos padrão", e o tipo de documento e a classificação precisam existir lá. A classificação é procurada pelo nome.
- As preferências são sempre criadas como individuais. Preferência de unidade ou de grupo continua sendo feita pelo eproc.
- A extensão não faz requisições externas: só conversa com o próprio eproc.
