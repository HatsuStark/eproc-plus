// Content script (mundo isolado) do Eproc+ para preferencias de minuta:
// - tela "Nova Minuta": botoes Copiar/Colar ao lado de "Atualizar preferencia";
// - tela do processo: botao "Copiar varias" no bloco Acoes preferenciais > Minutas.
// A leitura/gravacao no eproc e feita por pagina.js (mundo MAIN), chamado via window.postMessage.
(() => {
  'use strict';
  if (window.top !== window) return; // nao roda nos iframes ocultos que pagina.js abre

  const Prefs = globalThis.EprocPlusPrefs;
  const SEG_POR_COPIA = 2.5;  // medido no eproc1g: ~2,5 s por preferencia (espera a tela assentar; modelo incluido)
  const SEG_POR_COLAGEM = 1;  // conferencia de vinculo + gravacao
  const SEG_POR_MODELO = 6;   // criar modelo (tela, editor e salvamento): ~5,4 s medido
  const ORDEM_GRUPOS = ['Individuais', 'Unidade', 'Ocultas', 'Importadas', 'Outras'];

  // ------------------------------------------------------------- ponte

  const pendentes = new Map();
  let seq = 0;

  window.addEventListener('message', (ev) => {
    const d = ev.data;
    if (ev.source !== window || !d || !pendentes.has(d.id)) return;
    const p = pendentes.get(d.id);
    if (d.__eprocPlus === 'prog') { p.progresso?.(d.info); return; }
    if (d.__eprocPlus !== 'res') return;
    pendentes.delete(d.id);
    if (d.erro) p.reject(new Error(d.erro));
    else if (d.result?.erro) p.reject(new Error(d.result.erro));
    else p.resolve(d.result);
  });

  /** Chama window.__prefMinuta[metodo] na pagina. `opcoes.id` permite cancelar um lote. */
  function chamar(metodo, args = [], opcoes = {}) {
    const id = opcoes.id || `${Date.now()}-${++seq}`;
    return new Promise((resolve, reject) => {
      pendentes.set(id, { resolve, reject, progresso: opcoes.progresso });
      window.postMessage({ __eprocPlus: 'req', id, metodo, args }, location.origin);
    });
  }

  // ------------------------------------------------------------ utilitarios

  function el(tag, props = {}, ...filhos) {
    const e = Object.assign(document.createElement(tag), props);
    e.append(...filhos);
    return e;
  }

  const semAcento = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

  function formatarTempo(seg) {
    seg = Math.max(1, Math.round(seg));
    if (seg < 60) return `${seg} s`;
    const m = Math.floor(seg / 60);
    const s = seg % 60;
    return s ? `${m} min ${s} s` : `${m} min`;
  }

  let toastTimer;
  function toast(msg, ok = true) {
    let t = document.getElementById('eprocplus-toast');
    if (!t) {
      t = el('div', { id: 'eprocplus-toast' });
      document.body.append(t);
    }
    t.textContent = msg;
    t.className = ok ? 'ok' : 'erro';
    t.style.display = 'block';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.style.display = 'none'; }, ok ? 4000 : 9000);
  }

  /**
   * Checklist com filtro por nome, grupos (com "marcar o grupo") e "Todas (visiveis)".
   * itens: [{ chave, grupo, nome, detalhe?, etiqueta? }], ja na ordem de exibicao.
   */
  function criarChecklist(itens, aoMudar) {
    const marcadas = new Set();
    const caixas = new Map(); // chave -> checkbox
    const linhas = new Map(); // chave -> li
    const busca = el('input', { type: 'search', placeholder: 'Filtrar por nome...', className: 'eprocplus-busca' });
    const todas = el('input', { type: 'checkbox' });
    const contagem = el('span');
    const ul = el('ul', { className: 'eprocplus-lista' });
    const gruposChk = [];

    const visivel = (it) => linhas.get(it.chave).style.display !== 'none';
    const marcar = (it, valor) => {
      valor ? marcadas.add(it.chave) : marcadas.delete(it.chave);
      caixas.get(it.chave).checked = valor;
    };
    const atualizar = () => {
      const vis = itens.filter(visivel);
      todas.checked = vis.length > 0 && vis.every((it) => marcadas.has(it.chave));
      for (const { chk, doGrupo } of gruposChk) {
        const v = doGrupo.filter(visivel);
        chk.checked = v.length > 0 && v.every((it) => marcadas.has(it.chave));
      }
      aoMudar();
    };

    let grupoAtual = null;
    for (const it of itens) {
      if (it.grupo !== grupoAtual) {
        grupoAtual = it.grupo;
        const doGrupo = itens.filter((x) => x.grupo === it.grupo);
        const chk = el('input', { type: 'checkbox' });
        chk.addEventListener('change', () => { doGrupo.filter(visivel).forEach((x) => marcar(x, chk.checked)); atualizar(); });
        gruposChk.push({ chk, doGrupo });
        ul.append(el('li', { className: 'eprocplus-grupo' }, el('label', {}, chk, el('span', { textContent: `${it.grupo} (${doGrupo.length})` }))));
      }
      const chk = el('input', { type: 'checkbox' });
      caixas.set(it.chave, chk);
      chk.addEventListener('change', () => { marcar(it, chk.checked); atualizar(); });
      const label = el('label', {}, chk, el('span', { className: 'eprocplus-nome', textContent: it.nome }));
      if (it.detalhe) label.append(el('small', { textContent: it.detalhe }));
      if (it.etiqueta) label.append(el('small', { className: 'eprocplus-etiqueta', textContent: it.etiqueta }));
      const li = el('li', {}, label);
      linhas.set(it.chave, li);
      ul.append(li);
    }
    if (!itens.length) ul.append(el('li', { className: 'eprocplus-vazio', textContent: 'Nada para listar.' }));

    busca.addEventListener('input', () => {
      const termo = semAcento(busca.value);
      for (const it of itens) linhas.get(it.chave).style.display = !termo || semAcento(it.nome).includes(termo) ? '' : 'none';
      atualizar();
    });
    todas.addEventListener('change', () => { itens.filter(visivel).forEach((it) => marcar(it, todas.checked)); atualizar(); });

    return {
      elementos: [busca, el('div', { className: 'eprocplus-barra' }, el('label', {}, todas, ' Todas (visíveis)'), contagem), ul],
      busca,
      contagem,
      marcadas: () => itens.filter((it) => marcadas.has(it.chave)),
      selecionar: (chaves) => { const set = new Set(chaves); itens.forEach((it) => marcar(it, set.has(it.chave))); atualizar(); },
      bloquear: (sim) => { ul.querySelectorAll('input').forEach((c) => { c.disabled = sim; }); busca.disabled = todas.disabled = sim; },
      atualizar,
    };
  }

  /** Casca dos paineis: titulo, ajuda, conteudo, barra de progresso, status e botoes. */
  function criarPainel(titulo, ajuda, conteudo, botoes) {
    document.getElementById('eprocplus-painel')?.remove();
    const status = el('div', { className: 'eprocplus-status' });
    const barra = el('div', { className: 'eprocplus-progresso' }, el('div'));
    const confirmacao = el('div', { className: 'eprocplus-confirmacao', hidden: true });
    const acoes = el('div', { className: 'eprocplus-acoes' }, ...botoes);
    const painel = el('div', { id: 'eprocplus-painel' },
      el('div', { className: 'eprocplus-caixa', role: 'dialog', ariaLabel: titulo },
        el('h3', { textContent: titulo }), el('p', { className: 'eprocplus-ajuda', textContent: ajuda }), ...conteudo, barra, status,
        confirmacao, acoes));
    return {
      painel,
      /**
       * Pergunta dentro do painel (sem window.confirm, que o Chrome pode bloquear
       * sem mostrar nada). Resolve true em "sim", false em "nao".
       */
      perguntar: (texto, rotuloSim, rotuloNao = 'Voltar') => new Promise((resolve) => {
        const sim = el('button', { type: 'button', className: 'infraButton btn-primary', textContent: rotuloSim });
        const nao = el('button', { type: 'button', className: 'infraButton', textContent: rotuloNao });
        const fim = (v) => { confirmacao.hidden = true; confirmacao.replaceChildren(); acoes.hidden = false; resolve(v); };
        sim.addEventListener('click', () => fim(true));
        nao.addEventListener('click', () => fim(false));
        confirmacao.replaceChildren(el('div', { className: 'eprocplus-confirmacao-texto', textContent: texto }),
          el('div', { className: 'eprocplus-acoes' }, sim, nao));
        acoes.hidden = true;
        confirmacao.hidden = false;
        sim.focus();
      }),
      setStatus: (msg, cls = '') => { status.textContent = msg; status.className = 'eprocplus-status ' + cls; },
      progresso: (feitos, total) => {
        barra.style.display = 'block';
        barra.firstChild.style.width = `${Math.round((feitos / Math.max(1, total)) * 100)}%`;
      },
      abrir: () => document.body.append(painel),
    };
  }

  // -------------------------------------------------- copiar (Nova Minuta)

  async function copiar(botao) {
    botao.disabled = true;
    const texto = botao.textContent;
    botao.textContent = 'Copiando...';
    try {
      const cap = await chamar('capturar');
      const r = await Prefs.adicionarCaptura(cap);
      toast(`Eproc+ · ${r.mensagem}\nPara criar em outro usuário ou gerar um kit: 📥 Colar Preferências.`, r.ok);
    } catch (e) {
      toast('Eproc+ · ' + e.message, false);
    } finally {
      botao.disabled = false;
      botao.textContent = texto;
    }
  }

  // --------------------------------------------------- colar (Nova Minuta)

  async function abrirPainelColar(preSelecionar = []) {
    const preferencias = await Prefs.listar();
    const grupoDe = (p) => p.grupo || (p.importadaEm ? 'Importadas' : 'Outras');
    const ordenadas = [...preferencias].sort((a, b) =>
      (ORDEM_GRUPOS.indexOf(grupoDe(a)) - ORDEM_GRUPOS.indexOf(grupoDe(b))) || a.nome.localeCompare(b.nome, 'pt-BR'));
    const porChave = new Map(ordenadas.map((p) => [p.id, p]));

    const btnColar = el('button', { type: 'button', className: 'infraButton btn-primary', textContent: 'Colar',
      title: 'Cria as preferências marcadas no seu eproc (e os modelos que faltarem)' });
    const btnFechar = el('button', { type: 'button', className: 'infraButton', textContent: 'Fechar' });
    const btnExportar = el('button', { type: 'button', className: 'infraButton', textContent: '📦 Criar kit',
      title: 'Gera um arquivo com as preferências marcadas e os modelos delas, para enviar a um colega' });
    const btnImportar = el('button', { type: 'button', className: 'infraButton', textContent: '📂 Abrir kit recebido',
      title: 'Carrega o arquivo de kit que um colega te enviou; as preferências dele já vêm marcadas' });
    const arquivo = el('input', { type: 'file', accept: '.json,application/json', hidden: true });
    let ocupado = false;

    const lista = criarChecklist(ordenadas.map((p) => ({
      chave: p.id,
      grupo: grupoDe(p),
      nome: p.nome,
      detalhe: [p.resumo?.modelo, p.resumo?.novoLocalizador && `→ ${p.resumo.novoLocalizador}`].filter(Boolean).join(' '),
    })), () => {
      const marc = lista.marcadas();
      const comModelo = new Set(marc.map((it) => porChave.get(it.chave).modelo?.id).filter(Boolean)).size;
      const est = marc.length
        ? ` · tempo estimado ${formatarTempo(marc.length * SEG_POR_COLAGEM)} (+ até ${formatarTempo(comModelo * SEG_POR_MODELO)} se precisar criar os ${comModelo} modelo(s))`
        : '';
      lista.contagem.textContent = `${marc.length}/${ordenadas.length} selecionada(s)${est}`;
      btnColar.textContent = marc.length ? `Colar ${marc.length} selecionada(s)` : 'Colar';
      btnExportar.textContent = marc.length ? `📦 Criar kit com ${marc.length}` : '📦 Criar kit';
      btnColar.disabled = ocupado || !marc.length;
      btnExportar.disabled = ocupado || !marc.length;
    });

    const ui = criarPainel('Eproc+ · Colar Preferências',
      'Marque e clique em Colar para criar as preferências no seu eproc. Para mandar a um colega, marque e use 📦 Criar kit. Recebeu um kit? Use 📂 Abrir kit recebido.',
      [el('div', { className: 'eprocplus-ferramentas' }, btnImportar, btnExportar, arquivo), ...lista.elementos],
      [btnColar, btnFechar]);
    if (!ordenadas.length) ui.setStatus('Nenhuma preferência guardada ainda. Use 📋 Copiar Preferências na tela do processo, 📋 Copiar esta aqui na Nova Minuta, ou 📂 Abrir kit recebido.');

    btnFechar.addEventListener('click', () => { if (!ocupado) ui.painel.remove(); });
    ui.painel.addEventListener('mousedown', (ev) => { if (ev.target === ui.painel && !ocupado) ui.painel.remove(); });

    btnExportar.addEventListener('click', () => {
      const r = Prefs.exportarKit(lista.marcadas().map((it) => porChave.get(it.chave)));
      ui.setStatus(`Kit criado com ${r.preferencias} preferência(s) e ${r.modelos} modelo(s); o arquivo foi para a pasta Downloads.\nEnvie esse arquivo ao colega. Ele abre uma Nova Minuta, clica em 📥 Colar Preferências e em 📂 Abrir kit recebido.`, 'ok');
    });
    btnImportar.addEventListener('click', () => arquivo.click());
    arquivo.addEventListener('change', async () => {
      const f = arquivo.files[0];
      arquivo.value = '';
      if (!f) return;
      try {
        const r = await Prefs.importarKit(await f.text());
        await abrirPainelColar(r.ids);
        toast(`Eproc+ · Kit aberto: ${r.novas} nova(s)${r.repetidas ? `, ${r.repetidas} já existia(m)` : ''}. Já estão marcadas; confira e clique em Colar.`);
      } catch (e) {
        ui.setStatus('Falha ao importar: ' + e.message, 'erro');
      }
    });

    btnColar.addEventListener('click', async () => {
      const itens = lista.marcadas().map((it) => Prefs.paraColar(porChave.get(it.chave)));
      ocupado = true;
      lista.bloquear(true);
      btnFechar.disabled = btnImportar.disabled = true;
      lista.atualizar();
      try {
        const sim = await chamar('colar', [itens, true], {
          progresso: (p) => { ui.progresso(p.feitos, p.total); ui.setStatus(`Conferindo ${p.feitos + 1}/${p.total}: ${p.atual}`); },
        });
        const modelosNovos = sim.resultados.filter((r) => r.criaraModelo).length;
        const estimativa = formatarTempo(itens.length * SEG_POR_COLAGEM + modelosNovos * SEG_POR_MODELO);
        const comAviso = sim.resultados.filter((r) => r.avisos.length || r.erro);
        const pergunta = `${itens.length} preferência(s)${modelosNovos ? `, criando ${modelosNovos} modelo(s)` : ''}: ~${estimativa}.`;
        if (comAviso.length) {
          ui.setStatus('');
          const seguir = await ui.perguntar(`Atenção antes de criar (${pergunta})\n\n${Prefs.descreverResultados(comAviso)}`, 'Criar mesmo assim');
          if (!seguir) {
            ui.setStatus('Você escolheu voltar: nada foi criado.');
            return;
          }
        }
        const res = await chamar('colar', [itens, false], {
          progresso: (p) => {
            ui.progresso(p.feitos, p.total);
            ui.setStatus(`Criando ${p.feitos + 1}/${p.total} (~${estimativa} no total; não feche esta tela)\n${p.atual}`);
          },
        });
        ui.progresso(1, 1);
        const ok = res.resultados.filter((r) => r.status?.startsWith('gravada')).length;
        ui.setStatus(`${ok}/${itens.length} criada(s). Recarregue a tela (F5) para vê-las na lista de preferências.\n\n${Prefs.descreverResultados(res.resultados)}`,
          ok === itens.length ? 'ok' : 'erro');
        // Tambem no canto da tela, para o resultado nao se perder se o painel for fechado.
        const falhas = res.resultados.filter((r) => !r.status?.startsWith('gravada'));
        toast(`Eproc+ · ${ok}/${itens.length} preferência(s) criada(s).${falhas.length
          ? `\nNão criadas: ${falhas.map((r) => `${r.nome} (${r.erro || r.status})`).join('; ')}`
          : ' Aperte F5 para vê-las.'}`, ok === itens.length);
      } catch (e) {
        ui.setStatus(e.message, 'erro');
        toast('Eproc+ · Erro ao colar: ' + e.message, false);
      } finally {
        ocupado = false;
        lista.bloquear(false);
        btnFechar.disabled = btnImportar.disabled = false;
        lista.atualizar();
      }
    });

    ui.abrir();
    lista.selecionar(preSelecionar);
    lista.busca.focus();
  }

  // ----------------------------------------- copiar varias (tela do processo)

  async function abrirPainelLote() {
    const { itens } = await chamar('listarDaTela');
    const guardadas = await Prefs.listar();
    const porChave = new Map(itens.map((it, i) => [String(i), it]));

    const btnCopiar = el('button', { type: 'button', className: 'infraButton btn-primary', textContent: 'Copiar',
      title: 'Guarda na extensão as preferências marcadas, com os modelos; nada é alterado no eproc' });
    const btnFechar = el('button', { type: 'button', className: 'infraButton', textContent: 'Fechar' });
    let rodando = null; // id do lote em andamento

    const lista = criarChecklist(itens.map((it, i) => ({
      chave: String(i),
      grupo: it.grupo,
      nome: it.nome,
      etiqueta: Prefs.acharExistente(guardadas, location.host, it.idPreferencia) ? 'já copiada (será atualizada)' : '',
    })), () => {
      const n = lista.marcadas().length;
      lista.contagem.textContent = `${n}/${itens.length} selecionada(s)${n ? ` · tempo estimado ${formatarTempo(n * SEG_POR_COPIA)}` : ''}`;
      if (!rodando) btnCopiar.textContent = n ? `Copiar ${n} selecionada(s)` : 'Copiar';
      btnCopiar.disabled = !!rodando || !n;
    });
    const ui = criarPainel('Eproc+ · Copiar Preferências',
      'Marque as preferências que quer guardar na extensão (os modelos vão junto). Nada é alterado no eproc. Depois, numa Nova Minuta, use 📥 Colar Preferências para colar ou criar um kit.',
      lista.elementos, [btnCopiar, btnFechar]);

    btnFechar.addEventListener('click', () => {
      if (rodando) {
        chamar('cancelarLote', [rodando]);
        btnFechar.disabled = true;
        ui.setStatus('Cancelando depois da preferência atual...');
        return;
      }
      ui.painel.remove();
    });
    ui.painel.addEventListener('mousedown', (ev) => { if (ev.target === ui.painel && !rodando) ui.painel.remove(); });

    btnCopiar.addEventListener('click', async () => {
      const escolhidas = lista.marcadas().map((it) => {
        const { nome, url, grupo } = porChave.get(it.chave);
        return { nome, url, grupo };
      });
      rodando = `lote-${Date.now()}`;
      btnFechar.textContent = 'Cancelar';
      lista.bloquear(true);
      lista.atualizar();
      try {
        const res = await chamar('capturarVarias', [escolhidas], {
          id: rodando,
          progresso: (p) => {
            ui.progresso(p.feitos, p.total);
            if (p.fim) return;
            const media = p.feitos ? p.decorridoMs / 1000 / p.feitos : SEG_POR_COPIA;
            ui.setStatus(`${p.feitos}/${p.total} · faltam ~${formatarTempo((p.total - p.feitos) * media)}\nLendo: ${p.atual}`);
          },
        });
        const ok = res.resultados.filter((r) => r.ok);
        const falhas = res.resultados.filter((r) => !r.ok);
        const g = await Prefs.adicionarCapturas(ok.map((r) => r.captura));
        const linhas = [`${ok.length} copiada(s) em ${formatarTempo(res.decorridoMs / 1000)}: ${g.novas} nova(s), ${g.atualizadas} atualizada(s).`];
        if (res.resultados.length < escolhidas.length) linhas.push(`Cancelado: ${escolhidas.length - res.resultados.length} não lida(s).`);
        if (falhas.length) linhas.push('Falharam:', ...falhas.map((r) => `• ${r.nome}: ${r.erro}`));
        if (g.avisos.length) linhas.push('Avisos:', ...g.avisos.map((a) => `⚠ ${a}`));
        linhas.push('Próximo passo: abra uma Nova Minuta e clique em 📥 Colar Preferências para colar ou criar um kit.');
        ui.setStatus(linhas.join('\n'), falhas.length ? 'erro' : 'ok');
      } catch (e) {
        ui.setStatus(e.message, 'erro');
      } finally {
        rodando = null;
        btnFechar.textContent = 'Fechar';
        btnFechar.disabled = false;
        lista.bloquear(false);
        lista.atualizar();
      }
    });

    ui.abrir();
    lista.atualizar();
    lista.busca.focus();
  }

  // ------------------------------------------------------------- botoes

  function instalarNoProcesso() {
    if (document.getElementById('eprocplus-botoes-lote')) return true;
    const legenda = document.querySelector('#divMinPref > legend');
    if (!legenda) return false;
    const btn = el('button', { type: 'button', className: 'infraButton', id: 'eprocplus-botoes-lote', textContent: '📋 Copiar Preferências',
      title: 'Eproc+: escolher preferências desta lista para guardar na extensão (com os modelos)' });
    btn.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      abrirPainelLote().catch((e) => toast('Eproc+ · ' + e.message, false));
    });
    legenda.append(btn);
    return true;
  }

  function instalarNaMinuta() {
    if (document.getElementById('eprocplus-botoes')) return true;
    const ancora = document.getElementById('btnAtualizarPreferencias');
    if (!ancora || !document.getElementById('frmMinutaCadastro')) return false;
    const btnCopiar = el('button', { type: 'button', className: 'infraButton', textContent: '📋 Copiar esta',
      title: 'Eproc+: guarda na extensão a preferência carregada nesta tela (com o modelo)' });
    const btnColar = el('button', { type: 'button', className: 'infraButton', textContent: '📥 Colar Preferências',
      title: 'Eproc+: criar no seu eproc as preferências guardadas, criar um kit para colega ou abrir um kit recebido' });
    btnCopiar.addEventListener('click', () => copiar(btnCopiar));
    btnColar.addEventListener('click', () => abrirPainelColar().catch((e) => toast('Eproc+ · ' + e.message, false)));
    ancora.after(el('span', { id: 'eprocplus-botoes' }, btnCopiar, btnColar));
    return true;
  }

  const instalar = () => (/acao=processo_selecionar/.test(location.search) ? instalarNoProcesso() : instalarNaMinuta());

  if (!instalar()) {
    const obs = new MutationObserver(() => { if (instalar()) obs.disconnect(); });
    obs.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(() => obs.disconnect(), 30000);
  }
})();
