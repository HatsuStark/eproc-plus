// Popup do Eproc+: gerencia as preferencias copiadas (armazenamento.js) e, alem dos
// botoes da propria tela, tambem copia/cola chamando preferencias/pagina.js na aba
// do eproc (world MAIN, onde ficam o jQuery e as funcoes da tela Nova Minuta).

const Prefs = globalThis.EprocPlusPrefs;
const EM_ABA = new URLSearchParams(location.search).has('aba');

const el = (id) => document.getElementById(id);
const listaEl = el('lista');
let preferencias = [];
let selecionadas = new Set();

function setStatus(msg, tipo = '') {
  el('status').textContent = msg;
  el('status').className = tipo;
}

async function carregar() {
  preferencias = await Prefs.listar();
  render();
}

async function salvar() {
  await Prefs.gravar(preferencias);
  render();
}

function render() {
  selecionadas = new Set([...selecionadas].filter((id) => preferencias.some((p) => p.id === id)));
  listaEl.replaceChildren(...preferencias.map(itemLista));
  el('contagem').textContent = `${selecionadas.size}/${preferencias.length} selecionada(s)`;
  el('todas').checked = preferencias.length > 0 && selecionadas.size === preferencias.length;
  el('colar').disabled = selecionadas.size === 0;
  el('excluir').disabled = selecionadas.size === 0;
}

function itemLista(p) {
  const li = document.createElement('li');
  const linha = document.createElement('div');
  linha.className = 'item';

  const chk = document.createElement('input');
  chk.type = 'checkbox';
  chk.checked = selecionadas.has(p.id);
  chk.addEventListener('change', () => {
    chk.checked ? selecionadas.add(p.id) : selecionadas.delete(p.id);
    render();
  });

  const nome = document.createElement('input');
  nome.type = 'text';
  nome.value = p.nome;
  nome.title = 'Nome com que a preferência será criada (clique para editar)';
  nome.addEventListener('change', () => {
    p.nome = nome.value.trim() || p.nome;
    salvar();
  });

  linha.append(chk, nome);

  const det = document.createElement('details');
  const sum = document.createElement('summary');
  sum.textContent = 'detalhes';
  const dl = document.createElement('dl');
  const r = p.resumo || {};
  const campos = [
    ['Modelo', r.modelo],
    ['Modelo copiado', p.modelo
      ? `${p.modelo.tipo.texto} — ${p.modelo.descricao} (${p.modelo.codigo}; ${(p.modelo.classificacoes || []).map((c) => c.text).join(', ')}; ${p.modelo.publico ? 'público' : 'não público'})`
      : 'não (só a referência)'],
    ['Descrição', r.descricao],
    ['Assinante', r.assinante],
    ['Tratamento', r.tratamento],
    ['Status destino', r.statusDestino],
    ['Sigilo', r.sigilo],
    ['Evento agendado', r.agendamento ? r.evento : 'não'],
    ['Intimar', r.intimar],
    ['Comport. localizador', r.comportamentoLocalizador],
    ['Remover localiz.', r.localizadoresRemover],
    ['Novo localizador', r.novoLocalizador],
    ['Origem', [p.origem?.host, p.origem?.unidade].filter(Boolean).join(' — ')],
    ['Copiada em', p.capturadaEm && new Date(p.capturadaEm).toLocaleString('pt-BR')],
  ];
  for (const [k, v] of campos) {
    if (!v) continue;
    const dt = document.createElement('dt');
    dt.textContent = k;
    const dd = document.createElement('dd');
    dd.textContent = v;
    dl.append(dt, dd);
  }
  det.append(sum, dl);

  li.append(linha, det);
  return li;
}

/** Aba do eproc onde agir: a ativa (popup) ou a ultima tela Nova Minuta aberta (modo aba). */
async function abaEproc() {
  if (!EM_ABA) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab;
  }
  const tabs = await chrome.tabs.query({ url: 'https://*.tjsp.jus.br/*acao=minuta_cadastrar*' });
  tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  if (!tabs[0]) throw new Error('Nenhuma aba com a tela "Nova Minuta" aberta.');
  return tabs[0];
}

/** Injeta pagina.js na aba (world MAIN) e chama window.__prefMinuta[metodo](...args). */
async function executarNaPagina(metodo, args = []) {
  const tab = await abaEproc();
  if (!tab?.id || !/^https:\/\/[^/]*tjsp\.jus\.br\//.test(tab.url || '')) {
    throw new Error('Abra o eproc na tela "Nova Minuta" e clique na extensão de novo.');
  }
  const target = { tabId: tab.id };
  await chrome.scripting.executeScript({ target, world: 'MAIN', files: ['preferencias/pagina.js'] });
  const [res] = await chrome.scripting.executeScript({
    target,
    world: 'MAIN',
    func: (m, a) => window.__prefMinuta[m](...a),
    args: [metodo, args],
  });
  if (!res) throw new Error('A página não respondeu.');
  if (res.result?.erro) throw new Error(res.result.erro);
  return res.result;
}

el('copiar').addEventListener('click', async () => {
  setStatus('Lendo preferência e modelo da tela...');
  try {
    const r = await Prefs.adicionarCaptura(await executarNaPagina('capturar'));
    await carregar();
    setStatus(r.mensagem, r.ok ? 'ok' : 'erro');
  } catch (e) {
    setStatus(e.message, 'erro');
  }
});

el('todas').addEventListener('change', (ev) => {
  selecionadas = ev.target.checked ? new Set(preferencias.map((p) => p.id)) : new Set();
  render();
});

const descreverResultados = Prefs.descreverResultados;

el('colar').addEventListener('click', async () => {
  const itens = preferencias.filter((p) => selecionadas.has(p.id)).map(Prefs.paraColar);
  if (!itens.length) return;
  el('colar').disabled = true;
  try {
    setStatus('Conferindo...');
    const sim = await executarNaPagina('colar', [itens, true]);
    const comAviso = sim.resultados.filter((r) => r.avisos.length || r.erro);
    if (comAviso.length && !confirm(`Atenção:\n\n${descreverResultados(comAviso)}\n\nCriar mesmo assim?`)) {
      setStatus('Cancelado.');
      return;
    }
    setStatus(`Criando ${itens.length} preferência(s)... (modelos novos levam alguns segundos cada; não feche a aba)`);
    const res = await executarNaPagina('colar', [itens, false]);
    const ok = res.resultados.filter((r) => r.status?.startsWith('gravada')).length;
    setStatus(`${ok}/${itens.length} criada(s). Recarregue a tela (F5) para vê-las na lista.\n\n${descreverResultados(res.resultados)}`,
      ok === itens.length ? 'ok' : 'erro');
  } catch (e) {
    setStatus(e.message, 'erro');
  } finally {
    render();
  }
});

el('excluir').addEventListener('click', async () => {
  if (!confirm(`Excluir ${selecionadas.size} preferência(s) desta extensão? (Não mexe no eproc.)`)) return;
  preferencias = preferencias.filter((p) => !selecionadas.has(p.id));
  selecionadas.clear();
  await salvar();
  setStatus('Excluídas.');
});

el('exportar').addEventListener('click', () => {
  const lista = selecionadas.size ? preferencias.filter((p) => selecionadas.has(p.id)) : preferencias;
  if (!lista.length) return setStatus('Nada para exportar.', 'erro');
  const r = Prefs.exportarKit(lista);
  setStatus(`Kit criado com ${r.preferencias} preferência(s) e ${r.modelos} modelo(s); o arquivo foi para a pasta Downloads. Envie ao colega.`, 'ok');
});

el('importar').addEventListener('click', () => {
  // Abre o explorador de arquivos direto (no Windows o popup continua aberto durante a escolha).
  el('arquivo').click();
});

el('arquivo').addEventListener('change', async (ev) => {
  const arquivo = ev.target.files[0];
  ev.target.value = '';
  if (!arquivo) return;
  try {
    const r = await Prefs.importarKit(await arquivo.text());
    await carregar();
    setStatus(`Kit aberto: ${r.novas} preferência(s) nova(s)${r.repetidas ? `, ${r.repetidas} já existia(m)` : ''}.`, 'ok');
  } catch (e) {
    setStatus('Falha ao importar: ' + e.message, 'erro');
  }
});

// ------------------------------------------------- versao e atualizacao

function listaHtml(itens) {
  const ul = document.createElement('ul');
  for (const t of itens || []) ul.append(Object.assign(document.createElement('li'), { textContent: t }));
  return ul;
}

async function mostrarAtualizacao() {
  const { atualizacao } = await chrome.storage.local.get('atualizacao');
  const box = el('atualizacao');
  const nova = atualizacao?.nova;
  box.hidden = !nova;
  if (!nova) return;
  const link = Object.assign(document.createElement('a'), {
    href: nova.download || globalThis.EprocPlusConfig.URL_PAGINA, target: '_blank', textContent: 'Baixar',
  });
  box.replaceChildren(`Nova versão ${nova.versao} disponível. `, link,
    ' — extraia por cima da pasta atual e clique em ⟳ em chrome://extensions.', listaHtml(nova.novidades));
}

el('versao').textContent = 'v' + chrome.runtime.getManifest().version;

el('ver-novidades').addEventListener('click', async (ev) => {
  ev.preventDefault();
  const box = el('novidades');
  if (!box.hidden) { box.hidden = true; return; }
  const versoes = await (await fetch(chrome.runtime.getURL('novidades.json'))).json();
  box.replaceChildren(...versoes.flatMap((v) => [
    Object.assign(document.createElement('h4'), { textContent: `${v.versao} (${v.data.split('-').reverse().join('/')})` }),
    listaHtml(v.itens),
  ]));
  box.hidden = false;
});

el('verificar').addEventListener('click', async (ev) => {
  ev.preventDefault();
  setStatus('Verificando atualização...');
  try {
    await chrome.runtime.sendMessage({ tipo: 'eprocplus-verificar-versao' });
  } catch (e) {
    // Arquivos novos na pasta, mas a extensao nao foi recarregada: o popup e lido do disco,
    // o service worker (background.js) nao existe na versao carregada.
    setStatus('O verificador não respondeu. Clique em ⟳ na Eproc+ em chrome://extensions e tente de novo.', 'erro');
    return;
  }
  const { atualizacao } = await chrome.storage.local.get('atualizacao');
  await mostrarAtualizacao();
  if (atualizacao?.erro) setStatus('Não consegui verificar agora: ' + atualizacao.erro, 'erro');
  else setStatus(atualizacao?.nova ? `Versão ${atualizacao.nova.versao} disponível.` : 'Você está na versão mais nova.', 'ok');
});

if (EM_ABA) document.body.style.width = '520px';
carregar();
mostrarAtualizacao();
