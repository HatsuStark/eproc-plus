// Eproc+ · Relatorio Geral de Processos: busca por FRASE EXATA no "Conteudo do Lembrete".
//
// O eproc trata o campo como "qualquer das palavras" (OU): "Ato Mandado" traz quem tem
// "Ato" OU "Mandado". Com "Frase exata" marcada (ou o texto entre aspas), ao Consultar:
//   1. consulta cada palavra (mesma chamada da tabela, com os demais filtros) e intersecta;
//   2. le os lembretes completos dos processos restantes e confere a frase;
//   3. poe os numeros em "Lista de processos" e deixa o eproc consultar normalmente.
(() => {
  'use strict';
  if (window.top !== window) return;

  const CONCORRENCIA = 6;
  const ID = 'eprocplus-frase';
  // Lembretes de ato criados pela automacao de peticoes (src/peticoes/peticaoRecomendacao.js).
  // Manter os textos iguais aos de LEMBRETES_RECOMENDACAO.
  const LEMBRETES_RAPIDOS = [
    ['Custas', ['Ato Recolher Mandado', 'Ato Recolher Carta', 'Ato Recolher Pesquisa', 'Custas Ok - Pesquisas']],
    ['Andamento', ['Conferir Endereço', 'Pedido de Prazo', 'Ato Réplica', 'Concluso']],
    ['Perito', ['Manifestação do Perito', 'Intimar Perito']],
    ['Recurso', ['Ato Contrarrazões', 'Remessa TJ']],
  ];
  let listaQueColocamos = null; // valor que a extensao pos em txtMultiplosProcessos
  let ignorarProximoClique = false;

  const semAcento = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const normalizar = (s) => semAcento(s).toLowerCase().replace(/\s+/g, ' ').trim();
  const entreAspas = (s) => /^\s*["\u201c\u201d].*["\u201c\u201d]\s*$/.test(s);
  const tirarAspas = (s) => s.trim().replace(/^["\u201c\u201d]|["\u201c\u201d]$/g, '').trim();

  function el(tag, props = {}, ...filhos) {
    const e = Object.assign(document.createElement(tag), props);
    e.append(...filhos);
    return e;
  }

  // ---------------------------------------------------------- consultas

  function urlTabela() {
    const m = document.documentElement.innerHTML.match(/controlador\.php\?acao=relatorio_geral\/datatables_processo[^"'\s<>]*/);
    if (!m) throw new Error('Não achei a consulta do relatório nesta tela (o eproc mudou?).');
    return m[0].replace(/&amp;/g, '&');
  }

  /** Mesma chamada da tabela do relatorio, com os filtros do formulario e um lembrete trocado. */
  async function consultar(form, lembrete) {
    const p = new URLSearchParams(new FormData(form));
    p.set('txtLembrete', lembrete);
    p.set('draw', '1');
    p.set('start', '0');
    p.set('length', '20000');
    p.set('columns[0][data]', 'NumProcesso');
    p.set('order[0][column]', '0');
    p.set('order[0][dir]', 'asc');
    p.append('dt_customColumns[0][]', 'link_processo');
    p.append('dt_customColumns[0][]', 'NumProcesso');
    const resp = await fetch(urlTabela(), {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      body: p.toString(),
    });
    const texto = await resp.text();
    let j;
    try { j = JSON.parse(texto); } catch (e) {
      const erro = texto.match(/descricao="([^"]+)"/);
      throw new Error(erro ? erro[1] : 'Resposta inesperada do eproc ao consultar.');
    }
    return j.data.map((x) => ({
      num: x.NumProcesso,
      id: x.IdProcesso,
      seq: x.SeqProcesso,
      link: String(x.__customColumn__link_processo_NumProcesso || ''),
    }));
  }

  let urlLembretes = null;

  /** Endereco (com hash da sessao) da busca de lembretes; vem da tela de um processo. */
  async function obterUrlLembretes(proc) {
    if (urlLembretes) return urlLembretes;
    try { urlLembretes = sessionStorage.getItem('eprocplus-url-lembretes'); } catch (e) { /* sem storage */ }
    if (urlLembretes) return urlLembretes;
    const m = proc.link.match(/controlador\.php\?[^"'\s<>]+/);
    if (!m) throw new Error('Não achei o link do processo para ler os lembretes.');
    const html = await (await fetch(m[0].replace(/&amp;/g, '&'), { credentials: 'include' })).text();
    const u = html.match(/controlador_ajax\.php\?acao_ajax=montar_conteudo_lembretes&hash=[0-9a-f]+/);
    if (!u) throw new Error('Não achei a busca de lembretes na tela do processo (o eproc mudou?).');
    urlLembretes = u[0];
    try { sessionStorage.setItem('eprocplus-url-lembretes', urlLembretes); } catch (e) { /* sem storage */ }
    return urlLembretes;
  }

  /** Textos de todos os lembretes do processo (o mesmo quadro "Lembretes" da tela do processo). */
  async function lerLembretes(url, proc) {
    const body = new URLSearchParams({
      idProcesso: proc.id, seqProcesso: proc.seq, numProcesso: proc.num, paginaAtual: 'processo_selecionar', bolSoRelevantes: '',
    });
    const resp = await fetch(url, {
      method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body,
    });
    const html = new TextDecoder('iso-8859-1').decode(await resp.arrayBuffer());
    const doc = new DOMParser().parseFromString(html, 'text/html');
    return [...doc.querySelectorAll('.desLembrete')].map((d) => d.textContent);
  }

  async function emParalelo(itens, n, fn) {
    let i = 0;
    const trabalhadores = Array.from({ length: Math.min(n, itens.length) }, async () => {
      while (i < itens.length) {
        const atual = itens[i++];
        await fn(atual);
      }
    });
    await Promise.all(trabalhadores);
  }

  /** Processos (dos filtros atuais) cujos lembretes contem a frase exata. */
  async function buscarFrase(form, frase, aviso) {
    const palavras = [...new Set(normalizar(frase).split(' ').filter(Boolean))];
    aviso(`Consultando ${palavras.length} palavra(s)...`);
    let candidatos = null;
    for (const palavra of palavras) {
      const lista = await consultar(form, palavra);
      const nums = new Set(lista.map((p) => p.num));
      candidatos = candidatos ? candidatos.filter((p) => nums.has(p.num)) : lista;
      if (!candidatos.length) break;
    }
    const comTodas = candidatos.length;
    if (!comTodas) return { achados: [], comTodas };

    const url = await obterUrlLembretes(candidatos[0]);
    const alvo = normalizar(frase);
    const achados = [];
    let lidos = 0;
    await emParalelo(candidatos, CONCORRENCIA, async (proc) => {
      const textos = await lerLembretes(url, proc);
      if (textos.some((t) => normalizar(t).includes(alvo))) achados.push(proc.num);
      lidos++;
      if (lidos % 5 === 0 || lidos === comTodas) aviso(`Lendo lembretes: ${lidos}/${comTodas} processo(s) com todas as palavras...`);
    });
    return { achados, comTodas };
  }

  // ---------------------------------------------------------------- tela

  function faixa(form) {
    let f = document.getElementById(ID + '-faixa');
    if (!f) {
      f = el('div', { id: ID + '-faixa' });
      const tabela = document.getElementById('tblProcessoLista_wrapper') || document.getElementById('tblProcessoLista');
      (tabela ? tabela.parentElement : form).insertBefore(f, tabela || form.firstChild);
    }
    return f;
  }

  function mostrarFaixa(form, texto, tipo, comLimpar) {
    const f = faixa(form);
    f.className = tipo;
    f.replaceChildren(el('span', { textContent: texto }));
    if (comLimpar) {
      const b = el('button', { type: 'button', className: 'btn btn-sm btn-link', textContent: 'Limpar' });
      b.addEventListener('click', () => limpar(form));
      f.append(b);
    }
    f.hidden = false;
  }

  function limpar(form) {
    const lista = form.querySelector('#txtMultiplosProcessos');
    if (lista && listaQueColocamos !== null && lista.value === listaQueColocamos) lista.value = '';
    listaQueColocamos = null;
    const f = document.getElementById(ID + '-faixa');
    if (f) f.hidden = true;
  }

  function instalar() {
    const campo = document.getElementById('txtLembrete');
    const form = document.getElementById('frmProcessoLista');
    if (!campo || !form || document.getElementById(ID)) return !!document.getElementById(ID);

    const chk = el('input', { type: 'checkbox', id: ID });
    const rotulo = el('label', { htmlFor: ID, className: ID + '-rotulo',
      title: 'Eproc+: só processos com estas palavras juntas, nesta ordem (sem diferenciar maiúsculas e acentos). Escrever entre aspas também ativa.' },
    chk, ' Frase exata (Eproc+)');
    // Lista de lembretes da automacao: preenche o campo e liga a frase exata.
    const rapido = el('select', { className: ID + '-rapido', title: 'Eproc+: escolha um lembrete para buscar pela frase exata.' },
      el('option', { value: '', textContent: 'Lembrete rápido (Eproc+)…' }),
      ...LEMBRETES_RAPIDOS.map(([grupo, textos]) => el('optgroup', { label: grupo },
        ...textos.map((texto) => el('option', { value: texto, textContent: texto })))));
    rapido.addEventListener('change', () => {
      if (!rapido.value) return;
      campo.value = rapido.value;
      chk.checked = true;
      limpar(form);
      rapido.value = '';
      campo.focus();
    });

    (campo.closest('.form-group') || campo.parentElement).append(el('div', { className: ID + '-linha' }, rotulo, rapido));
    chk.addEventListener('change', () => { if (!chk.checked) limpar(form); });

    // Intercepta o Consultar antes do eproc (fase de captura).
    document.addEventListener('click', async (ev) => {
      const botao = ev.target.closest && ev.target.closest('button.btnConsultar');
      if (!botao) return;
      if (ignorarProximoClique) { ignorarProximoClique = false; return; }
      const valor = campo.value;
      const exata = chk.checked || entreAspas(valor);
      const frase = tirarAspas(valor);
      if (!exata || !frase) {
        limpar(form);
        return;
      }
      ev.preventDefault();
      ev.stopImmediatePropagation();
      const listaCampo = form.querySelector('#txtMultiplosProcessos');
      // Lista que nos mesmos pusemos numa busca anterior nao pode restringir a nova.
      if (listaCampo && listaQueColocamos !== null && listaCampo.value === listaQueColocamos) listaCampo.value = '';
      listaQueColocamos = null;
      if (entreAspas(valor)) { campo.value = frase; chk.checked = true; }
      botao.disabled = true;
      try {
        const r = await buscarFrase(form, frase, (msg) => mostrarFaixa(form, `Eproc+ · Frase exata "${frase}": ${msg}`, 'andamento'));
        if (!r.achados.length) {
          mostrarFaixa(form, `Eproc+ · Nenhum processo com a frase exata "${frase}"`
            + (r.comTodas ? ` (${r.comTodas} têm as palavras, mas não juntas).` : ' (nenhum tem todas as palavras).'), 'vazio', true);
          return;
        }
        listaQueColocamos = r.achados.join(';');
        listaCampo.value = listaQueColocamos;
        mostrarFaixa(form, `Eproc+ · ${r.achados.length} processo(s) com a frase exata "${frase}" `
          + `(de ${r.comTodas} com todas as palavras). A lista foi posta em "Lista de processos".`, 'ok', true);
        ignorarProximoClique = true;
        botao.disabled = false;
        botao.click();
      } catch (e) {
        mostrarFaixa(form, 'Eproc+ · Frase exata: ' + e.message, 'erro', true);
      } finally {
        botao.disabled = false;
      }
    }, true);
    return true;
  }

  if (!instalar()) {
    const obs = new MutationObserver(() => { if (instalar()) obs.disconnect(); });
    obs.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(() => obs.disconnect(), 30000);
  }
})();
