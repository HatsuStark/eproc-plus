// Service worker do Eproc+: confere de tempos em tempos se ha versao nova publicada
// (config.js) e marca o icone com um selo. O popup mostra o aviso e o link de download.
importScripts('config.js');

const { URL_VERSAO, HORAS_ENTRE_CONSULTAS } = globalThis.EprocPlusConfig;
const ALARME = 'eprocplus-verificar-versao';

/** -1, 0 ou 1 comparando "1.2.10" com "1.10.0" numericamente. */
function compararVersoes(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return Math.sign(d);
  }
  return 0;
}

async function verificarVersao() {
  if (!URL_VERSAO) return;
  try {
    const resp = await fetch(URL_VERSAO, { cache: 'no-store' });
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const publicada = await resp.json();
    const atual = chrome.runtime.getManifest().version;
    const nova = compararVersoes(publicada.versao, atual) > 0 ? publicada : null;
    await chrome.storage.local.set({ atualizacao: { nova, verificadoEm: new Date().toISOString() } });
    await chrome.action.setBadgeText({ text: nova ? 'novo' : '' });
    if (nova) await chrome.action.setBadgeBackgroundColor({ color: '#1d6b38' });
  } catch (e) {
    // Sem internet ou repositorio fora do ar: tenta de novo no proximo alarme.
    await chrome.storage.local.set({ atualizacao: { erro: e.message, verificadoEm: new Date().toISOString() } });
  }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(ALARME, { periodInMinutes: HORAS_ENTRE_CONSULTAS * 60, delayInMinutes: 1 });
  verificarVersao();
});
chrome.runtime.onStartup.addListener(verificarVersao);
chrome.alarms.onAlarm.addListener((a) => { if (a.name === ALARME) verificarVersao(); });
chrome.runtime.onMessage.addListener((msg, _sender, responder) => {
  if (msg?.tipo === 'eprocplus-verificar-versao') {
    verificarVersao().then(() => responder(true));
    return true;
  }
  return false;
});
