(() => {
  'use strict';
  // Não atua em outras páginas do TJSP.
  if (!location.hostname.toLowerCase().includes('eproc')) return;

  const SELECTOR = '#selNovoLocalizador';
  const UI_ID = 'eproc-pesquisa-localizador-principal';
  const CSS = `
    #${UI_ID} { position: fixed; z-index: 9999; box-sizing: border-box; }
    #${UI_ID} input { width: 100%; height: 100%; box-sizing: border-box; padding: 0 5px; border: 1px solid #aaa; border-radius: 3px; }
    #${UI_ID} .epl-menu { display: none; position: absolute; left: 0; width: 100%; max-height: 240px; overflow-y: auto;
      background: #fff; border: 1px solid #aaa; box-sizing: border-box; box-shadow: 0 3px 8px #0002; z-index: 10000; }
    #${UI_ID} .epl-menu.epl-baixo { top: 100%; }
    #${UI_ID} .epl-menu.epl-cima { bottom: 100%; }
    #${UI_ID} .epl-item { padding: 5px 7px; cursor: pointer; border-bottom: 1px solid #eee; }
    #${UI_ID} .epl-item.epl-ativo { background: #e8f1ff; }
    #${UI_ID} .epl-vazio { padding: 7px; color: #777; }
  `;

  let currentSelect = null;
  let overlay = null;
  let input = null;
  let menu = null;
  let itens = [];   // [{ option, texto, chave }] montado ao abrir o menu
  let visiveis = []; // itens filtrados, na ordem do menu
  let ativo = -1;    // indice em `visiveis` destacado pelo teclado/mouse

  const normalize = (value) => String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('pt-BR');

  // Agrupa varios disparos (mutacoes, scroll, resize) em no maximo 1 execucao por quadro.
  function porQuadro(fn) {
    let agendado = false;
    return () => {
      if (agendado) return;
      agendado = true;
      requestAnimationFrame(() => { agendado = false; fn(); });
    };
  }

  function position() {
    if (!overlay || !currentSelect?.isConnected) return;
    const r = currentSelect.getBoundingClientRect();
    const visible = r.width > 0 && r.height > 0 && getComputedStyle(currentSelect).visibility !== 'hidden';
    overlay.style.display = visible ? 'block' : 'none';
    if (!visible) return;
    Object.assign(overlay.style, { top: `${r.top}px`, left: `${r.left}px`, width: `${r.width}px`, height: `${r.height}px` });
    input.disabled = currentSelect.disabled;
  }

  const isOpen = () => menu?.style.display === 'block';

  function closeMenu() {
    if (menu) menu.style.display = 'none';
    ativo = -1;
  }

  function sync() {
    if (currentSelect && input) input.value = currentSelect.selectedOptions[0]?.textContent.trim() || '';
  }

  function escolher(option) {
    if (!option || !currentSelect?.isConnected) return;
    currentSelect.value = option.value;
    // Mantém o onchange nativo do eproc (marcar principal/habilitar secundários).
    currentSelect.dispatchEvent(new Event('change', { bubbles: true }));
    sync();
    closeMenu();
  }

  function destacar(indice) {
    menu.children[ativo]?.classList.remove('epl-ativo');
    ativo = indice;
    const el = menu.children[ativo];
    if (el) {
      el.classList.add('epl-ativo');
      el.scrollIntoView({ block: 'nearest' });
    }
  }

  function render(term = '') {
    if (!currentSelect?.isConnected) return;
    const chave = normalize(term);
    visiveis = chave ? itens.filter((it) => it.chave.includes(chave)) : itens;
    const fragment = document.createDocumentFragment();
    visiveis.forEach((it, i) => {
      const div = document.createElement('div');
      div.className = 'epl-item';
      div.textContent = it.texto;
      div.dataset.i = i;
      fragment.appendChild(div);
    });
    if (!visiveis.length) {
      const vazio = document.createElement('div');
      vazio.className = 'epl-vazio';
      vazio.textContent = 'Nenhum localizador encontrado';
      fragment.appendChild(vazio);
    }
    menu.replaceChildren(fragment);
    ativo = -1;
    if (chave && visiveis.length) destacar(0);

    // Abre para cima quando nao cabe embaixo.
    const r = overlay.getBoundingClientRect();
    const cima = window.innerHeight - r.bottom < 240 && r.top > window.innerHeight - r.bottom;
    menu.className = 'epl-menu ' + (cima ? 'epl-cima' : 'epl-baixo');
    menu.style.display = 'block';
  }

  function abrir() {
    // Normaliza os textos uma vez por abertura (as opcoes podem mudar entre aberturas).
    itens = Array.from(currentSelect.options, (option) => {
      const texto = option.textContent.trim();
      return { option, texto, chave: normalize(texto) };
    });
    input.select();
    render();
  }

  function destroy() {
    closeMenu();
    overlay?.remove();
    overlay = input = menu = currentSelect = null;
    itens = visiveis = [];
  }

  function setup(select) {
    destroy();
    currentSelect = select;
    if (!document.getElementById(UI_ID + '-css')) {
      const style = document.createElement('style');
      style.id = UI_ID + '-css';
      style.textContent = CSS;
      (document.head || document.documentElement).appendChild(style);
    }
    const s = getComputedStyle(select);
    const fonte = { fontFamily: s.fontFamily, fontSize: s.fontSize, fontWeight: s.fontWeight, color: s.color };

    overlay = document.createElement('div');
    overlay.id = UI_ID;
    Object.assign(overlay.style, fonte);

    input = document.createElement('input');
    input.type = 'text';
    input.autocomplete = 'off';
    input.spellcheck = false;
    input.setAttribute('aria-label', 'Pesquisar localizador principal');
    input.placeholder = 'Pesquisar localizador...';
    Object.assign(input.style, fonte, {
      background: s.backgroundColor === 'rgba(0, 0, 0, 0)' ? '#fff' : s.backgroundColor,
      lineHeight: s.lineHeight
    });

    menu = document.createElement('div');
    menu.className = 'epl-menu epl-baixo';
    Object.assign(menu.style, fonte);

    // Um listener so para todos os itens (delegacao).
    menu.addEventListener('mousedown', (event) => {
      event.preventDefault();
      const item = event.target.closest('.epl-item');
      if (item) escolher(visiveis[item.dataset.i]?.option);
    });
    menu.addEventListener('mousemove', (event) => {
      const item = event.target.closest('.epl-item');
      if (item && Number(item.dataset.i) !== ativo) destacar(Number(item.dataset.i));
    });

    input.addEventListener('focus', abrir);
    input.addEventListener('input', () => render(input.value));
    input.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') { closeMenu(); sync(); input.blur(); return; }
      if (!isOpen()) {
        if (event.key === 'ArrowDown') { event.preventDefault(); abrir(); }
        return;
      }
      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault();
        if (!visiveis.length) return;
        const passo = event.key === 'ArrowDown' ? 1 : -1;
        destacar((ativo + passo + visiveis.length) % visiveis.length);
      } else if (event.key === 'Enter') {
        event.preventDefault();
        escolher(visiveis[ativo >= 0 ? ativo : 0]?.option);
      }
    });
    select.addEventListener('change', () => { if (currentSelect === select) sync(); });

    overlay.append(input, menu);
    document.body.appendChild(overlay);
    sync();
    position();
  }

  function scan() {
    const select = document.querySelector(SELECTOR);
    if (!select) { if (currentSelect) destroy(); return; }
    if (select !== currentSelect || !overlay?.isConnected) setup(select);
    position();
  }

  document.addEventListener('mousedown', (event) => {
    if (overlay && !overlay.contains(event.target) && isOpen()) { closeMenu(); sync(); }
  });
  const reposicionar = porQuadro(position);
  window.addEventListener('scroll', reposicionar, { capture: true, passive: true });
  window.addEventListener('resize', reposicionar, { passive: true });
  // O eproc pode adicionar o seletor depois da carga e trocar partes da tela.
  const observer = new MutationObserver(porQuadro(scan));
  observer.observe(document.documentElement, { childList: true, subtree: true });
  scan();
})();
