# Eproc+

Extensão do Chrome com melhorias para o eproc do TJSP:

1. **Pesquisa no localizador principal.** Na tela Nova Minuta, o campo "Novo localizador" ganha uma caixa de pesquisa. O campo original continua no formulário e recebe o evento `change` quando você escolhe um item.
2. **Copiar e colar preferências de minuta.** Copia a preferência carregada na tela, com o modelo junto, e recria em outro usuário com 1 clique.

## Instalar

1. Abra `chrome://extensions` e ative o **Modo do desenvolvedor**.
2. Clique em **Carregar sem compactação** e escolha esta pasta, a que contém o `manifest.json`.
3. Atualize as abas do eproc que já estavam abertas.

Para atualizar, troque os arquivos e clique em ⟳ na extensão, em `chrome://extensions`.

> As preferências copiadas ficam guardadas por extensão. Se você usava a extensão antiga "eproc - Preferências de Minuta", use **Exportar** nela antes de removê-la e depois **Importar** na Eproc+.

## Preferências de minuta

Funciona em três passos: **copiar** as preferências para a extensão, **colar** no seu eproc ou **criar um kit** para um colega.

| Onde | Botão | O que faz |
|---|---|---|
| Tela do processo (Ações preferenciais › Minutas) | **📋 Copiar Preferências** | Abre a lista das preferências do processo para escolher quais guardar na extensão |
| Nova Minuta (ao lado de "Atualizar preferência") | **📋 Copiar esta** | Guarda só a preferência carregada na tela |
| Nova Minuta | **📥 Colar Preferências** | Abre o painel para colar, criar um kit ou abrir um kit recebido |

### 1. Copiar

O **📋 Copiar Preferências** abre uma checklist com as preferências listadas no processo: Individuais, Unidade e Ocultas. Tem filtro por nome, marcação por grupo e tempo estimado, cerca de 1,2 s por preferência. Também avisa quais já foram copiadas antes; essas serão atualizadas.

Cada preferência é guardada completa: o modelo, a descrição, o assinante, o tratamento, o status de destino, o sigilo, o agendamento de evento e intimação e o comportamento do localizador. O modelo vai junto, com tipo, descrição, classificação, se é público e o texto das seções.

Nada é alterado no eproc. Para cada preferência, a extensão abre a Nova Minuta num iframe oculto e só lê. Modelos repetidos são lidos uma vez só. Dá para cancelar no meio.

### 2. Colar

No **📥 Colar Preferências**:
1. Marque as preferências. O painel tem filtro, grupos (Individuais, Unidade, Ocultas e Importadas) e tempo estimado.
2. Clique em **Colar N selecionada(s)**.

Cada uma é criada como preferência **individual** do usuário logado.

Antes de gravar, a extensão:
- confere se o localizador, o assinante e o tratamento existem na unidade e avisa se algum faltar;
- verifica se o modelo existe. Se não existir, procura um modelo com a mesma descrição e o mesmo tipo. Se também não achar, cria o modelo (tela "Novo modelo padrão", editor e salvamento pelo próprio eproc, numa janela oculta), uma vez só para cada modelo.

Antes de criar qualquer coisa, a extensão mostra o tempo previsto e pede confirmação: cerca de 1 s por preferência, mais uns 6 s para cada modelo novo.

### 3. Kit para colegas

- **📦 Criar kit**, no painel Colar: gera um arquivo `.json` com as preferências marcadas e os modelos delas. O arquivo vai para a pasta Downloads; envie ao colega.
- **📂 Abrir kit recebido**: o colega abre uma Nova Minuta, clica em **📥 Colar Preferências** e depois nesse botão. As preferências do kit já vêm marcadas; é só clicar em **Colar**.

O ícone da extensão abre o mesmo controle, com mais opções: criar e abrir kit, renomear e excluir. No popup, abrir um kit abre uma aba própria.

## Como funciona

- `preferencias/pagina.js` roda no mundo da página, porque precisa do jQuery e das funções do eproc.
  - Para copiar, ele chama a `validarPreferencias()` da própria tela, mas troca `gravarPreferencias()` para só guardar a `listaDados`. Assim nada é gravado.
  - Para colar, ele envia a `listaDados` para `gravar_preferencias_cadastrar_formulario`, depois de passar por `validar_acao_preferencial_vinculo_localizadores`. É o mesmo caminho do botão "Salvar Nova Preferência".
- `preferencias/botoes.js` roda isolado. Cuida dos botões, do painel e do `chrome.storage`, e conversa com o `pagina.js` por `window.postMessage`.
- `localizador/pesquisa.js` é a pesquisa do localizador principal.

## Versões e atualização

- A versão aparece no rodapé do popup. **Novidades** mostra o histórico, que fica em `novidades.json`.
- De 6 em 6 horas, o `background.js` lê o `versao.json` do repositório público [HatsuStark/eproc-plus](https://github.com/HatsuStark/eproc-plus). Se houver versão nova, o ícone ganha o selo **novo** e o popup mostra o link para baixar. Também dá para conferir na hora em **Verificar atualização**.
- **Para publicar uma versão:**
  1. Suba o `version` no `manifest.json` e acrescente a versão no topo de `novidades.json`.
  2. Rode `node ferramentas/empacotar-eproc-plus.js <pasta-do-clone-do-repo-publico>`. O script gera `eproc-plus-<versão>.zip`, `versao.json` e `README.md`.
  3. Faça commit e push no repositório público.

## Limitações

- Os IDs de localizador e assinante valem dentro da mesma unidade e da mesma instância do eproc. O eproc cível (`eproc1g`) e o da execução fiscal (`eproc1g-ef`) usam IDs diferentes.
- Para criar o modelo, o usuário de destino precisa de acesso a "Modelos padrão", e o tipo de documento e a classificação precisam existir lá. A classificação é procurada pelo nome.
- As preferências são sempre criadas como individuais. Preferência de unidade ou de grupo continua sendo feita pelo eproc.
- A extensão não faz requisições externas: só conversa com o próprio eproc.
