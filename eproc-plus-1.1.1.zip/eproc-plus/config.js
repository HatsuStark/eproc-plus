// Onde o Eproc+ procura versao nova (repositorio publico so da extensao).
// versao.json: { "versao": "1.2.0", "download": "<url do zip>", "novidades": ["..."] }
globalThis.EprocPlusConfig = {
  URL_VERSAO: 'https://raw.githubusercontent.com/HatsuStark/eproc-plus/main/versao.json',
  URL_PAGINA: 'https://github.com/HatsuStark/eproc-plus',
  HORAS_ENTRE_CONSULTAS: 6,
};
