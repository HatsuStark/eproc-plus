// Injetado na tela "Nova Minuta" do eproc (world: MAIN) via chrome.scripting.executeScript
// com `files`. Expoe window.__prefMinuta, chamado depois pelo popup.
// Roda no contexto da pagina para usar o jQuery e as funcoes do proprio eproc.
(() => {
  const ESPERA_PADRAO_MS = 30000;

  const dormir = (ms) => new Promise((r) => setTimeout(r, ms));

  async function esperar(condicao, descricao, timeout = ESPERA_PADRAO_MS) {
    const fim = Date.now() + timeout;
    for (;;) {
      let v;
      try { v = condicao(); } catch (e) { v = null; }
      if (v) return v;
      if (Date.now() > fim) throw new Error('Tempo esgotado esperando ' + descricao + '.');
      await dormir(250);
    }
  }

  // O eproc serve as paginas em ISO-8859-1.
  async function buscarHtml(url, opcoes) {
    const resp = await fetch(url, Object.assign({ credentials: 'include' }, opcoes));
    if (!resp.ok) throw new Error('HTTP ' + resp.status + ' em ' + url);
    return new TextDecoder('iso-8859-1').decode(await resp.arrayBuffer());
  }

  const parseHtml = (html) => new DOMParser().parseFromString(html, 'text/html');

  /** Abre a URL num iframe oculto e espera `pronto(win)` ficar verdadeiro. */
  async function abrirIframe(url, pronto, descricao) {
    const ifr = document.createElement('iframe');
    ifr.style.cssText = 'position:fixed;left:-10000px;top:0;width:1200px;height:900px;visibility:hidden';
    ifr.src = url;
    document.body.appendChild(ifr);
    try {
      await esperar(() => {
        const w = ifr.contentWindow;
        return w && w.document && w.document.readyState === 'complete' && pronto(w);
      }, descricao);
      return ifr;
    } catch (e) {
      ifr.remove();
      throw e;
    }
  }

  /** Silencia alert/confirm do iframe e guarda as mensagens. */
  function capturarDialogos(w, mensagens) {
    w.alert = (m) => { mensagens.push(String(m)); };
    w.confirm = (m) => { mensagens.push(String(m)); return true; };
  }

  // ---------------------------------------------------------------- copiar

  /**
   * Le tipo, descricao, classificacao, publico e texto das secoes do modelo da tela `doc`.
   * `cache` (id do modelo -> promessa) evita reler o mesmo modelo numa copia em lote.
   */
  async function capturarModelo(doc = document, cache = null) {
    const partes = (doc.getElementById('hdnIdModeloMatrizModeloPadrao') || {}).value;
    if (!partes) return null;
    const campos = partes.split('|');
    const id = campos[1];
    if (!id) return null;
    if (cache) {
      if (!cache.has(id)) cache.set(id, lerModelo(campos));
      return cache.get(id);
    }
    return lerModelo(campos);
  }

  async function lerModelo(campos) {
    const [idMatriz, id, codigo] = campos;
    const links = campos.filter((p) => p.length > 40).map((p) => { try { return atob(p); } catch (e) { return ''; } });
    const urlConsultar = links.find((l) => l.includes('acao=modelo_padrao_consultar'));
    const urlVisualizar = links.find((l) => l.includes('acao=modelo_padrao_visualizar_lista'));
    if (!urlConsultar || !urlVisualizar) throw new Error('Links do modelo não encontrados na tela.');

    const cons = parseHtml(await buscarHtml(urlConsultar));
    const sel = cons.getElementById('selModeloMatriz');
    const opt = sel && [...sel.options].find((o) => o.selected);
    let classificacoes = [];
    try {
      classificacoes = JSON.parse((cons.getElementById('selClassificacaoConteudo').value || '[]').split("'").join('"'));
    } catch (e) { /* sem classificacao */ }

    const ifr = await abrirIframe(urlVisualizar, (w) => {
      const interno = w.document.getElementById('iframe_modelo_padrao');
      const d = interno && interno.contentDocument;
      return d && d.readyState === 'complete' && d.querySelector('section[data-nome]');
    }, 'o conteúdo do modelo');
    let secoes;
    try {
      const d = ifr.contentWindow.document.getElementById('iframe_modelo_padrao').contentDocument;
      secoes = Object.fromEntries([...d.querySelectorAll('section[data-nome]')].map((s) => [s.dataset.nome, s.innerHTML.trim()]));
    } finally {
      ifr.remove();
    }

    return {
      id,
      codigo,
      tipo: { id: idMatriz, texto: opt ? opt.text.trim() : '' },
      descricao: (cons.getElementById('txtDesModeloPadrao') || {}).value || '',
      classificacoes,
      publico: !!(cons.getElementById('chkSinPublico') || {}).checked,
      secoes,
    };
  }

  /**
   * Le a preferencia carregada na tela. Usa a propria validarPreferencias() do eproc
   * (a do botao "Salvar Nova Preferencia"), trocando gravarPreferencias() para pegar a
   * listaDados sem gravar nada. `w` e a janela da tela (a propria ou a de um iframe oculto).
   */
  async function capturar(w = window, cacheModelos = null) {
    const $ = w.jQuery;
    const form = w.document.getElementById('frmMinutaCadastro');
    if (!form || typeof w.validarPreferencias !== 'function' || typeof $ !== 'function') {
      return { erro: 'Abra a tela "Nova Minuta" de um processo, com a preferência carregada.' };
    }
    const texto = (s) => ($(s).val() || '').trim();
    const textoOpcao = (s) => $(s + ' option:selected').map((_, o) => o.text.trim()).get().join('; ');

    const actionAntes = form.action;
    const gravarOriginal = w.gravarPreferencias;
    let listaDados = null;
    w.gravarPreferencias = (lista) => { listaDados = lista; };
    try {
      w.validarPreferencias();
    } catch (e) {
      return { erro: 'Falha ao ler a preferência da tela: ' + e.message };
    } finally {
      w.gravarPreferencias = gravarOriginal;
      form.action = actionAntes;
    }
    if (!listaDados) return { erro: 'O eproc não montou os dados da preferência (validação da tela falhou?).' };

    let modelo = null;
    let avisoModelo = '';
    try {
      modelo = await capturarModelo(w.document, cacheModelos);
    } catch (e) {
      avisoModelo = 'Modelo não copiado: ' + e.message;
    }

    const agendamento = $('#chkEventoAgendamento').is(':checked');
    const rdLoc = $('input[name=rdPrefLocalizadores]:checked');
    const tipoPref = $('input[name=rdPrefTipo]:checked').val();
    return {
      nome: texto('#txtPreferencia') || texto('#txtDescricao'),
      grupo: tipoPref === 'U' ? 'Unidade' : tipoPref === 'I' ? 'Individuais' : '',
      listaDados,
      movPreferencial: $('#chkMovPreferencial').is(':checked'),
      modelo,
      avisoModelo,
      origem: {
        host: w.location.host,
        unidade: textoOpcao('#selInfraUnidades:first'),
        idPreferencia: texto('#hdnPreferencia'),
      },
      resumo: {
        modelo: texto('#txtModelo'),
        descricao: texto('#txtDescricao'),
        assinante: textoOpcao('#selAssinante'),
        tratamento: textoOpcao('#selTratamento'),
        statusDestino: textoOpcao('#selStatusMinuta'),
        sigilo: textoOpcao('#selSigilo'),
        agendamento,
        evento: agendamento ? texto('#txtEvento') : '',
        intimar: agendamento && $('#chkEncadeamentoIntimar').is(':checked') ? textoOpcao('#selEventoEncadeadoCitacaoIntimacao') : '',
        comportamentoLocalizador: textoOpcao('#selOpcaoLocalizador'),
        localizadoresRemover: (rdLoc.next('label').text() || rdLoc.val() || '').trim(),
        novoLocalizador: textoOpcao('#selNovoLocalizador'),
      },
      // Ids usados no "colar" para avisar quando o destino nao conhece o valor.
      ids: {
        novoLocalizador: texto('#selNovoLocalizador'),
        assinante: texto('#selAssinante'),
        tratamento: texto('#selTratamento'),
      },
    };
  }

  // ------------------------------------------------------- copiar em lote

  /** Preferencias de minuta listadas no bloco "Acoes preferenciais" da tela do processo. */
  function listarDaTela() {
    const grupos = [
      ['preferencia-minuta-individual', 'Individuais'],
      ['preferencia-minuta-unidade', 'Unidade'],
      ['preferencia-minuta-ocultas', 'Ocultas'],
    ];
    const itens = [];
    for (const [idDiv, grupo] of grupos) {
      const div = document.getElementById(idDiv);
      if (!div) continue;
      for (const a of div.querySelectorAll('a[href*="acao=minuta_cadastrar"]')) {
        const url = new URL(a.getAttribute('href'), location.href);
        itens.push({ grupo, nome: a.textContent.trim(), url: url.href, idPreferencia: url.searchParams.get('num_id_form_personalizacao') });
      }
    }
    if (!itens.length) return { erro: 'Nenhuma preferência de minuta listada nesta tela (abra a tela do processo com o bloco "Minutas" visível).' };
    return { itens };
  }

  const cancelamentos = new Set();

  /**
   * Copia varias preferencias: abre cada link (tela Nova Minuta ja com a preferencia
   * carregada) num iframe oculto e roda capturar() nele. Nada e gravado no eproc.
   * `progresso(info)` e chamado a cada item.
   */
  async function capturarVarias(itens, idLote, progresso = () => {}) {
    const cacheModelos = new Map();
    const resultados = [];
    const inicio = Date.now();
    for (let i = 0; i < itens.length; i++) {
      if (cancelamentos.has(idLote)) { cancelamentos.delete(idLote); break; }
      const item = itens[i];
      progresso({ feitos: i, total: itens.length, atual: item.nome, decorridoMs: Date.now() - inicio });
      let ifr;
      try {
        ifr = await abrirIframe(item.url, (w) => {
          if (!w.__eprocPlusSilenciado && w.document.readyState !== 'loading') {
            // Silencia alert/confirm da tela oculta (gravar nada; so ler).
            w.alert = () => {};
            w.confirm = () => true;
            w.__eprocPlusSilenciado = true;
          }
          return w.document.getElementById('frmMinutaCadastro') && typeof w.validarPreferencias === 'function' && w.jQuery;
        }, 'a tela da preferência', 60000);
        const cap = await capturar(ifr.contentWindow, cacheModelos);
        if (cap.erro) throw new Error(cap.erro);
        if (!cap.nome) cap.nome = item.nome;
        if (item.grupo) cap.grupo = item.grupo;
        resultados.push({ nome: item.nome, ok: true, captura: cap });
      } catch (e) {
        resultados.push({ nome: item.nome, ok: false, erro: e.message });
      } finally {
        if (ifr) ifr.remove();
      }
    }
    progresso({ feitos: resultados.length, total: itens.length, atual: '', decorridoMs: Date.now() - inicio, fim: true });
    return { resultados, decorridoMs: Date.now() - inicio };
  }

  // ----------------------------------------------------------------- colar

  /** Pesquisa modelos visiveis ao usuario (mesmo autocompletar do campo "Tipo de documento/Modelo"). */
  async function pesquisarModelos(termo) {
    const url = window.mc_strLinkAjaxModelo;
    if (!url) throw new Error('Pesquisa de modelos indisponível nesta tela.');
    const xml = await buscarHtml(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'particula=' + encodeURIComponent(termo),
    });
    const doc = new DOMParser().parseFromString(xml, 'text/xml');
    return [...doc.querySelectorAll('item')].map((it) => {
      const p = (it.getAttribute('id') || '').split('|');
      return { idMatriz: p[0], id: p[1], codigo: p[2], descricao: it.getAttribute('descricao') || '' };
    }).filter((m) => m.id);
  }

  /** Modelo equivalente ja acessivel no destino: o proprio (mesmo id) ou um com a mesma descricao. */
  async function acharModeloNoDestino(modelo) {
    const porCodigo = await pesquisarModelos(modelo.codigo);
    const mesmo = porCodigo.find((m) => m.id === modelo.id);
    if (mesmo) return { ...mesmo, igual: true };
    const desc = modelo.descricao.trim().toLowerCase();
    if (!desc) return null;
    const porDescricao = await pesquisarModelos(modelo.descricao);
    return porDescricao.find((m) => m.idMatriz === modelo.tipo.id && m.descricao.toLowerCase().includes(desc)) || null;
  }

  async function urlNovoModelo() {
    const link = document.querySelector('a[href*="acao=modelo_padrao_listar"]');
    if (!link) throw new Error('Link "Modelos padrão" não encontrado no menu (sem permissão para criar modelos?).');
    const html = await buscarHtml(link.getAttribute('href'));
    const m = html.match(/controlador\.php\?acao=modelo_padrao_cadastrar[^"'\s<>]*/);
    if (!m) throw new Error('Botão "Novo" de modelos padrão não encontrado (sem permissão para criar modelos?).');
    return m[0].replace(/&amp;/g, '&');
  }

  /** Classificacoes do destino com o mesmo texto das de origem (o select2 da tela usa esse ajax). */
  async function mapearClassificacoes(w, classificacoes) {
    const fonte = w.document.documentElement.innerHTML;
    const m = fonte.match(/controlador_ajax\.php\?acao_ajax=montar_classificacao_conteudo[^"'\s]*/);
    if (!m) return classificacoes;
    const url = m[0].replace(/&amp;/g, '&');
    const achadas = [];
    for (const c of classificacoes) {
      const json = await buscarHtml(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'txtClassificacao=' + encodeURIComponent(c.text) + '&valorAtual=',
      });
      let lista = [];
      try { lista = JSON.parse(json); } catch (e) { /* resposta inesperada */ }
      const planas = [].concat(...(Array.isArray(lista) ? lista : []).map((x) => [x].concat(x.children || [])));
      const igual = planas.find((x) => x.id === c.id) || planas.find((x) => String(x.text).trim().toLowerCase() === c.text.trim().toLowerCase());
      if (!igual) throw new Error('Classificação "' + c.text + '" não existe no destino.');
      achadas.push({ id: igual.id, text: igual.text });
    }
    return achadas;
  }

  /** Cria o modelo num iframe oculto (tela "Novo modelo padrao" + editor) e devolve id/codigo novos. */
  async function criarModelo(modelo, descricao) {
    const mensagens = [];
    const ifr = await abrirIframe(await urlNovoModelo(),
      (w) => w.document.getElementById('frmModeloPadraoCadastro') && w.jQuery, 'a tela de novo modelo');
    try {
      let w = ifr.contentWindow;
      capturarDialogos(w, mensagens);
      const $w = w.jQuery;

      const sel = w.document.getElementById('selModeloMatriz');
      const opcao = [...sel.options].find((o) => o.value === modelo.tipo.id)
        || [...sel.options].find((o) => o.text.trim().toLowerCase() === modelo.tipo.texto.toLowerCase());
      if (!opcao) throw new Error('Tipo de documento "' + modelo.tipo.texto + '" não existe no destino.');
      $w(sel).val(opcao.value).trigger('change');
      w.document.getElementById('txtDesModeloPadrao').value = descricao;
      $w('#selClassificacaoConteudo').select2('data', await mapearClassificacoes(w, modelo.classificacoes));
      w.document.getElementById('chkSinPublico').checked = modelo.publico;
      if (!w.validarCadastro()) throw new Error('Tela de novo modelo recusou: ' + mensagens.join(' / '));

      const form = w.document.getElementById('frmModeloPadraoCadastro');
      form.requestSubmit(form.querySelector('button[name=sbmCadastrarModeloPadrao]'));

      // Depois do Salvar o eproc abre o editor do modelo novo no mesmo frame.
      await esperar(() => {
        const x = ifr.contentWindow;
        if (!x || !/acao=modelo_padrao_editar/.test(x.location.href) || x.document.readyState !== 'complete') return false;
        const inst = x.CKEDITOR && Object.values(x.CKEDITOR.instances);
        return inst && inst.length && inst.every((e) => e.status === 'ready');
      }, 'o editor do modelo novo', 60000);
      w = ifr.contentWindow;
      capturarDialogos(w, mensagens);

      const id = new URL(w.location.href).searchParams.get('id_modelo_padrao');
      const instancias = Object.values(w.CKEDITOR.instances);
      const codigo = instancias[0].name.split('_')[0];
      if (!id || !/^\d+$/.test(codigo)) throw new Error('Não consegui identificar o modelo criado.');

      // Texto: so as secoes editaveis, casadas por data-nome. Ids de paragrafo da origem saem
      // (o eproc gera novos); data-hash/data-timestamp ficam.
      const editaveis = instancias.filter((e) => !e.readOnly);
      let preenchidas = 0;
      for (const ed of editaveis) {
        const nome = ed.element && ed.element.getAttribute('data-nome');
        if (!nome || !(nome in modelo.secoes)) continue;
        const html = modelo.secoes[nome].replace(/\s+id="\d+_\d+"/g, '');
        await new Promise((res) => ed.setData(html, { callback: () => { ed.updateElement(); res(); } }));
        preenchidas++;
      }
      const avisos = [];
      if (!preenchidas) avisos.push('modelo criado sem texto (seções não correspondem)');

      if (preenchidas) {
        const info = () => (w.document.getElementById('infoMessage') || {}).textContent || '';
        editaveis[0].execCommand('salvar');
        await esperar(() => /Documento salvo/i.test(info()) && !editaveis.some((e) => e.checkDirty()), 'o salvamento do texto do modelo', 60000);
      }
      if (mensagens.length) avisos.push(...mensagens);
      return { id, codigo, idMatriz: opcao.value, avisos };
    } finally {
      ifr.remove();
    }
  }

  /** Aponta a preferencia para outro modelo (listaDados e formularios serializados em base64). */
  function trocarModelo(listaDados, antigo, novo) {
    const troca = (s) => s.split(antigo.codigo).join(novo.codigo).split(antigo.id).join(novo.id)
      .split(antigo.idMatriz).join(novo.idMatriz);
    return listaDados
      .replace(/(^|,)ModeloPadrao\|[^,;]*;[^,]*/, '$1ModeloPadrao|' + novo.codigo + ';' + novo.idMatriz)
      .replace(/(^|,)(Agendamento|frmDadosMinutaParaATP)\|([A-Za-z0-9+/=]+)/g, (_, ini, chave, b64) => {
        try { return ini + chave + '|' + btoa(troca(atob(b64))); } catch (e) { return ini + chave + '|' + b64; }
      });
  }

  /**
   * Grava as preferencias como novas preferencias individuais do usuario logado, pelo
   * mesmo endpoint do botao "Salvar Nova Preferencia". Cria o modelo quando o destino nao o tem.
   * Com simular=true so confere, sem gravar nada.
   */
  async function colar(itens, simular, opcoes = {}, progresso = () => {}) {
    const $ = window.jQuery;
    if (!document.getElementById('frmMinutaCadastro') || typeof window.gravarPreferencias !== 'function' || typeof $ !== 'function') {
      return { erro: 'Abra a tela "Nova Minuta" de qualquer processo para colar as preferências.' };
    }
    const fonte = window.gravarPreferencias.toString();
    const achar = (acao) => {
      const m = fonte.match(new RegExp('controlador_ajax\\.php\\?acao_ajax=' + acao + '&hash=[0-9a-f]+'));
      return m && m[0];
    };
    const urlGravar = achar('gravar_preferencias_cadastrar_formulario');
    const urlVinculo = achar('validar_acao_preferencial_vinculo_localizadores');
    if (!urlGravar) return { erro: 'Não achei o endereço de gravação de preferências nesta tela (o eproc mudou?).' };

    const post = (url, dados) => new Promise((resolve, reject) => {
      $.post(url, dados).done(resolve).fail((xhr) => reject(new Error('HTTP ' + xhr.status)));
    });
    const codificar = typeof window.toHtmlEntityDecimal === 'function'
      ? window.toHtmlEntityDecimal
      : (s) => Array.from(s, (c) => (c.charCodeAt(0) > 159 ? '&#' + c.charCodeAt(0) + ';' : c)).join('');
    const existeOpcao = (sel, valor) => !valor || $(sel).find('option').filter((_, o) => o.value === valor).length > 0;
    const modelosResolvidos = new Map(); // id do modelo de origem -> {id, codigo, idMatriz} no destino

    const resultados = [];
    const inicio = Date.now();
    for (const item of itens) {
      progresso({ feitos: resultados.length, total: itens.length, atual: item.nome, decorridoMs: Date.now() - inicio });
      const r = { nome: item.nome, avisos: [] };
      resultados.push(r);
      try {
        if (item.ids) {
          if (!existeOpcao('#selNovoLocalizador', item.ids.novoLocalizador)) r.avisos.push('novo localizador não existe nesta unidade');
          if (!existeOpcao('#selAssinante', item.ids.assinante)) r.avisos.push('assinante não disponível aqui');
          if (!existeOpcao('#selTratamento', item.ids.tratamento)) r.avisos.push('tratamento não disponível aqui');
        }

        let listaDados = item.listaDados;
        const m = item.modelo;
        if (m) {
          const antigo = { id: m.id, codigo: m.codigo, idMatriz: m.tipo.id };
          let destino = modelosResolvidos.get(m.id);
          if (!destino) {
            // forcarCriacao: so para teste na propria unidade de origem.
            const achado = opcoes.forcarCriacao ? null : await acharModeloNoDestino(m);
            if (achado) {
              destino = achado;
              if (!achado.igual) r.avisos.push('usará o modelo já existente ' + achado.codigo + ' (mesma descrição)');
            } else if (simular) {
              r.criaraModelo = true;
              r.avisos.push('modelo "' + m.descricao + '" não existe aqui e será criado');
            } else {
              const criado = await criarModelo(m, m.descricao);
              r.modeloCriado = criado.codigo;
              r.avisos.push(...criado.avisos);
              destino = criado;
            }
            if (destino) modelosResolvidos.set(m.id, destino);
          }
          if (destino && destino.id !== m.id) listaDados = trocarModelo(listaDados, antigo, destino);
        }

        const postar = {
          listaDados,
          chkValorPadrao: 'N',
          chkMovPreferencial: item.movPreferencial ? 'S' : 'N',
          txtDescricaoCadastro: codificar(item.nome),
          nomeAcao: 'minuta_cadastrar',
          rdPrefTipo: 'I',
          sinExibirPainel: 'N',
          selGrupo: 'null',
        };
        if (urlVinculo) {
          const ret = String(await post(urlVinculo, postar) || '');
          if (ret) {
            const [tipo, msg] = ret.split('|');
            if (tipo === 'P') {
              if (simular) r.avisos.push('eproc vai perguntar: ' + msg);
              else if (!window.confirm('Preferência "' + item.nome + '":\n\n' + msg)) { r.status = 'cancelada'; continue; }
            } else if (msg) {
              r.avisos.push(msg);
            }
          }
        }
        if (simular) { r.status = 'ok (simulação)'; continue; }
        const resp = await post(urlGravar, postar);
        const obj = typeof resp === 'string' ? JSON.parse(resp) : resp;
        if (obj.sucesso !== 'true') { r.status = 'erro'; r.erro = obj.msg || 'eproc recusou'; continue; }
        r.status = r.modeloCriado ? 'gravada (modelo ' + r.modeloCriado + ' criado)' : 'gravada';
        r.idPreferencia = obj.idPreferencia;
      } catch (e) {
        r.status = 'erro';
        r.erro = e.message;
      }
    }
    return { resultados };
  }

  window.__prefMinuta = {
    capturar: () => capturar(),
    colar,
    listarDaTela,
    capturarVarias,
    cancelarLote: (idLote) => { cancelamentos.add(idLote); return true; },
    trocarModelo,
    pesquisarModelos,
  };

  // Ponte com botoes.js (content script isolado, que nao enxerga o jQuery da pagina):
  // pedido {__eprocPlus:'req', id, metodo, args} -> resposta {__eprocPlus:'res', id, result|erro};
  // capturarVarias e colar tambem mandam {__eprocPlus:'prog', id, info} a cada item.
  if (!window.__prefMinutaPonte) {
    window.__prefMinutaPonte = true;
    window.addEventListener('message', async (ev) => {
      const d = ev.data;
      if (ev.source !== window || !d || d.__eprocPlus !== 'req') return;
      let resp;
      try {
        const api = window.__prefMinuta;
        const progresso = (info) => window.postMessage({ __eprocPlus: 'prog', id: d.id, info }, location.origin);
        if (d.metodo === 'capturarVarias') {
          resp = { result: await api.capturarVarias(d.args[0], d.id, progresso) };
        } else if (d.metodo === 'colar') {
          const [itens, simular, opcoes] = d.args;
          resp = { result: await api.colar(itens, simular, opcoes || {}, progresso) };
        } else if (['capturar', 'listarDaTela', 'cancelarLote'].includes(d.metodo)) {
          resp = { result: await api[d.metodo](...(d.args || [])) };
        } else {
          throw new Error('Método desconhecido: ' + d.metodo);
        }
      } catch (e) {
        resp = { erro: e.message };
      }
      window.postMessage({ __eprocPlus: 'res', id: d.id, ...resp }, location.origin);
    });
  }
})();
