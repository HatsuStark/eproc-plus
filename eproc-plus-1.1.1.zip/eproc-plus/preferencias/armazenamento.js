// Preferencias copiadas, em chrome.storage.local. Usado pelo popup e por botoes.js.
globalThis.EprocPlusPrefs = (() => {
  const CHAVE = 'preferencias';

  async function listar() {
    const dados = await chrome.storage.local.get(CHAVE);
    return dados[CHAVE] || [];
  }

  async function gravar(preferencias) {
    await chrome.storage.local.set({ [CHAVE]: preferencias });
  }

  /** A mesma preferencia do eproc (mesmo host e id) ja guardada. */
  const acharExistente = (preferencias, host, idPreferencia) =>
    idPreferencia && preferencias.find((p) => p.origem?.host === host && p.origem?.idPreferencia === idPreferencia);

  /** Junta uma captura na lista; recapturar a mesma preferencia atualiza a existente. */
  function mesclar(preferencias, cap) {
    const avisoModelo = cap.avisoModelo || '';
    delete cap.avisoModelo;
    if (!cap.nome) cap.nome = 'Preferência sem nome';
    const agora = new Date().toISOString();
    const existente = acharExistente(preferencias, cap.origem.host, cap.origem.idPreferencia);
    if (existente) {
      Object.assign(existente, cap, { nome: existente.nome, capturadaEm: agora });
    } else {
      preferencias.push({ id: crypto.randomUUID(), capturadaEm: agora, ...cap });
    }
    return { atualizada: !!existente, nome: existente ? existente.nome : cap.nome, avisoModelo };
  }

  async function adicionarCaptura(cap) {
    const preferencias = await listar();
    const r = mesclar(preferencias, cap);
    await gravar(preferencias);
    const mensagem = `${r.atualizada ? 'Atualizada' : 'Copiada'}: "${r.nome}"`;
    return { mensagem: mensagem + (r.avisoModelo ? `\n⚠ ${r.avisoModelo}` : ''), ok: !r.avisoModelo };
  }

  /** Varias capturas numa gravacao so (copia em lote). */
  async function adicionarCapturas(caps) {
    const preferencias = await listar();
    const r = { novas: 0, atualizadas: 0, avisos: [] };
    for (const cap of caps) {
      const m = mesclar(preferencias, cap);
      m.atualizada ? r.atualizadas++ : r.novas++;
      if (m.avisoModelo) r.avisos.push(`${m.nome}: ${m.avisoModelo}`);
    }
    await gravar(preferencias);
    return r;
  }

  /** So os campos que a pagina precisa para colar. */
  const paraColar = (p) => ({ nome: p.nome, listaDados: p.listaDados, movPreferencial: p.movPreferencial, ids: p.ids, modelo: p.modelo });

  function descreverResultados(resultados) {
    return resultados.map((r) => {
      let linha = `• ${r.nome}: ${r.status}`;
      if (r.erro) linha += ` — ${r.erro}`;
      if (r.avisos?.length) linha += `\n   ⚠ ${r.avisos.join('\n   ⚠ ')}`;
      return linha;
    }).join('\n');
  }

  // ------------------------------------------------------------ kit (arquivo)

  const TIPO_KIT = 'eproc-preferencias-minuta';

  /** Baixa as preferencias (com modelos) num .json para outro usuario importar. */
  function exportarKit(lista) {
    const modelos = new Set(lista.map((p) => p.modelo?.id).filter(Boolean));
    const kit = {
      tipo: TIPO_KIT,
      versao: 1,
      geradoEm: new Date().toISOString(),
      resumo: { preferencias: lista.length, modelos: modelos.size },
      preferencias: lista,
    };
    const blob = new Blob([JSON.stringify(kit, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `kit-eproc-plus-${lista.length}-preferencias-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
    return { preferencias: lista.length, modelos: modelos.size };
  }

  /** Junta um kit ao que ja esta guardado. Devolve os ids (locais) das preferencias do kit. */
  async function importarKit(texto) {
    let dados;
    try { dados = JSON.parse(texto); } catch (e) { throw new Error('Arquivo não é JSON válido.'); }
    if (dados.tipo !== TIPO_KIT || !Array.isArray(dados.preferencias)) {
      throw new Error('Arquivo não é um kit/exportação do Eproc+.');
    }
    const preferencias = await listar();
    const ids = [];
    let novas = 0;
    for (const p of dados.preferencias) {
      if (!p.listaDados || !p.nome) continue;
      const igual = preferencias.find((q) => q.listaDados === p.listaDados && q.nome === p.nome);
      if (igual) { ids.push(igual.id); continue; }
      const id = crypto.randomUUID();
      preferencias.push({ ...p, id, importadaEm: new Date().toISOString() });
      ids.push(id);
      novas++;
    }
    await gravar(preferencias);
    return { novas, repetidas: ids.length - novas, ids };
  }

  return {
    listar, gravar, acharExistente, adicionarCaptura, adicionarCapturas, paraColar, descreverResultados,
    exportarKit, importarKit,
  };
})();
